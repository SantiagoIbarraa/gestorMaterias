SELECT * FROM pg_policies WHERE tablename = 'horario';
SELECT count(*) FROM horario;
